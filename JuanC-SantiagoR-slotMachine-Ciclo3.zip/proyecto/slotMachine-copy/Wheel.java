import java.util.ArrayList;
import java.util.Random;

/**
 * Representa una rueda de la maquina.
 *
 * Una rueda contiene varios simbolos y mantiene uno de ellos
 * como el simbolo actualmente seleccionado.
 *
 * @author Juan Felipe Carvajal Moyano, Santiago Rodriguez Reyes
 */
public class Wheel
{
    /* Lista de simbolos de la rueda */
    private ArrayList<Symbol> symbols;

    /* Posicion grafica de la rueda */
    private int xPosition;
    private int yPosition;

    /* Indice del simbolo actualmente seleccionado */
    private int currentSymbol;

    /* Indica si la rueda esta visible */
    private boolean isVisible;

    /* Generador para seleccionar simbolos */
    private Random random;


    /**
     * Crea una rueda vacia.
     *
     * @param x posicion horizontal
     * @param y posicion vertical
     */
    public Wheel(int x, int y)
    {
        symbols = new ArrayList<Symbol>();

        xPosition = x;
        yPosition = y;

        currentSymbol = 0;

        isVisible = false;

        random = new Random();
    }


    /**
     * Agrega un simbolo a la rueda.
     *
     * @param symbol simbolo que se desea agregar
     */
    public void addSymbol(Symbol symbol)
    {
        if (symbol != null)
        {
            /*
             * El simbolo debe estar en la misma posicion
             * que la rueda.
             */
            symbol.setPosition(xPosition, yPosition);

            symbols.add(symbol);

            /*
             * Si es el primer simbolo se convierte
             * en el simbolo actualmente seleccionado.
             */
            if (symbols.size() == 1)
            {
                currentSymbol = 0;

                if (isVisible)
                {
                    symbol.makeVisible();
                }
            }
            else
            {
                /*
                 * Los demas simbolos permanecen ocultos.
                 */
                symbol.makeInvisible();
            }
        }
    }


    /**
     * Elimina un simbolo por su color.
     *
     * @param color color del simbolo
     * @return true si se elimino correctamente
     */
    public boolean removeSymbol(String color)
    {
        for (int i = 0; i < symbols.size(); i++)
        {
            if (symbols.get(i).getColor().equals(color))
            {
                Symbol symbol = symbols.get(i);

                symbol.makeInvisible();

                symbols.remove(i);

                /*
                 * Si ya no quedan simbolos,
                 * reiniciamos el indice.
                 */
                if (symbols.size() == 0)
                {
                    currentSymbol = 0;
                }

                /*
                 * Si el indice quedo fuera del arreglo,
                 * regresamos al primer simbolo.
                 */
                else if (currentSymbol >= symbols.size())
                {
                    currentSymbol = 0;
                }

                updateVisibleSymbol();

                return true;
            }
        }

        return false;
    }


    /**
     * Selecciona aleatoriamente uno de los simbolos.
     *
     * Este metodo representa un cambio de seleccion
     * dentro de la rueda.
     */
    public void spin()
    {
        if (symbols.size() == 0)
        {
            return;
        }

        /*
         * Ocultamos el simbolo actual.
         */
        symbols.get(currentSymbol).makeInvisible();

        /*
         * Seleccionamos otro simbolo.
         */
        currentSymbol = random.nextInt(symbols.size());

        /*
         * Actualizamos el simbolo visible.
         */
        updateVisibleSymbol();
    }


    /**
     * Actualiza el simbolo que debe estar visible.
     */
    private void updateVisibleSymbol()
    {
        if (symbols.size() > 0)
        {
            Symbol symbol = symbols.get(currentSymbol);

            /*
             * El simbolo debe conservar la posicion
             * actual de la rueda.
             */
            symbol.setPosition(xPosition, yPosition);

            if (isVisible)
            {
                symbol.makeVisible();
            }
        }
    }


    /**
     * Cambia la posicion de la rueda.
     *
     * Tambien mueve los simbolos que pertenecen
     * a la rueda.
     *
     * @param x nueva posicion horizontal
     * @param y nueva posicion vertical
     */
    public void setPosition(int x, int y)
    {
        xPosition = x;
        yPosition = y;

        /*
         * Todos los simbolos deben seguir
         * a la rueda.
         */
        for (Symbol symbol : symbols)
        {
            symbol.setPosition(xPosition, yPosition);
        }
    }


    /**
     * Retorna el color del simbolo actualmente seleccionado.
     *
     * @return color del simbolo
     */
    public String getCurrentColor()
    {
        if (symbols.size() == 0)
        {
            return "";
        }

        return symbols.get(currentSymbol).getColor();
    }


    /**
     * Hace visible la rueda.
     */
    public void makeVisible()
    {
        isVisible = true;

        if (symbols.size() > 0)
        {
            symbols.get(currentSymbol).makeVisible();
        }
    }


    /**
     * Hace invisible la rueda.
     */
    public void makeInvisible()
    {
        isVisible = false;

        for (Symbol symbol : symbols)
        {
            symbol.makeInvisible();
        }
    }


    /**
     * Retorna la cantidad de simbolos.
     *
     * @return cantidad de simbolos
     */
    public int symbolCount()
    {
        return symbols.size();
    }


    /**
     * Retorna los colores de los simbolos.
     *
     * @return arreglo con los colores
     */
    public String[] getSymbols()
    {
        String[] result = new String[symbols.size()];

        for (int i = 0; i < symbols.size(); i++)
        {
            result[i] = symbols.get(i).getColor();
        }

        return result;
    }
}