/**
 * Simbolo que se encoge cada vez que es seleccionado hasta quedar como un punto
 * 
 * @author Juan Carvajal Moyano-Santiago Rodriguez Reyes
 */

public class EphemeralSymbol extends Symbol
{
    private static final int STEP = 5;
    private static final int MIN_SIZE = 5;   // "punto"

    public EphemeralSymbol(String color, int x, int y)
    {
        super(color, x, y);
    }

    @Override
    public void onSelected()
    {
        if (getDiameter() > MIN_SIZE)
        {
            resize(Math.max(MIN_SIZE, getDiameter() - STEP));
        }
    }

}