
/**
 * Rueda que, al girar, copia el estado de la rueda de su izquierda
 * 
 * @author Juan Cavajal Moyano-Santiago Rodriguez Reyes
 */
public class LeftyWheel extends Wheel
{
    public LeftyWheel(int x, int y)
    {
        super(x, y);
    }

    @Override
    public void spin(Wheel left)
    {
        if (left == null || !showColor(left.getCurrentColor()))
        {
            spin();   // sin vecina, gira como una normal
        }
    }
}