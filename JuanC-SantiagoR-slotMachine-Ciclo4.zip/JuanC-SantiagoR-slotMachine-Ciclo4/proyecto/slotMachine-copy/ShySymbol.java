
/**
 * cada vez que es seleccionado alterna entre visible e invisible
 * 
 * @author Juan Carvajal Moyano-Santiago Rodriguez Reyes
 */
public class ShySymbol extends Symbol
{
    private boolean hidden = false;

    public ShySymbol(String color, int x, int y)
    {
        super(color, x, y);
    }

    @Override
    public void onSelected()
    {
        hidden = !hidden;
        if (hidden)
        {
            super.makeInvisible();
        }
    }

    /* Si esta timido, la rueda no lo muestra */
    @Override
    public void makeVisible()
    {
        if (!hidden)
        {
            super.makeVisible();
        }
    }
}